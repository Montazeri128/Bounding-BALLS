//
// Created by Laptop Markazi on ۲۵/۰۱/۲۰۲۴.
//

#ifndef UNTITLED20_FUNCTIONS_H
#define UNTITLED20_FUNCTIONS_H


#include <bits/stdc++.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL2_gfx.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <SDL2/SDL_image.h>


using namespace std;



//متغیر های گلوبال
string username = "";

struct User {
    std::string username;
    int data[4];
};
enum PageState {
    HOME_PAGE,
    SETTING_PAGE,
    LEADERBOARD_PAGE,
    NORMAL_MODE,
    TIME_MODE,
    RANDOM_MODE,
    SURVIVAL_MODE,
    MENU_PAGE,
    LOSE_PAGE,
    WIN_PAGE

};
enum SOUND {
    SOUND_ON,
    SOUND_OFF
};

enum MUSIC {
    MUSIC_ON,
    MUSIC_OFF
};

enum MUSICs {
    MUSIC1,
    MUSIC2,
    MUSIC3,
    MUSIC4
};
enum BACKGROUND {
    THEME1,
    THEME2,
    THEME3,
    THEME4
};
enum LOGIN {
    WAITING_FOR_USERNAME,
    LOGED_IN,
    SIGNED_UP
};

void window_color(SDL_Renderer *Renderer, int R, int G, int B){
    SDL_SetRenderDrawColor(Renderer, R, G, B, 225);
    SDL_RenderClear(Renderer);

}
void ellipse(SDL_Renderer *Renderer,int x,int y,int Radius1,int Radius2,int R,int G,int B,int fill_boolian)
{
    if(fill_boolian==1)
        filledEllipseRGBA(Renderer,x,y,Radius1,Radius2,R,G,B,255);
    if(fill_boolian==0)
        ellipseRGBA(Renderer,x,y,Radius1,Radius2,R,G,B,255);
}
void rect(SDL_Renderer *Renderer,int x,int y,int w,int h,int R,int G,int B,int fill_boolian)
{
    SDL_Rect rectangle;
    rectangle.x=x;
    rectangle.y=y;
    rectangle.w=w;
    rectangle.h=h;
}
void my_line(SDL_Renderer *Renderer,int x_1,int y_1,int L,double theta,int width,int R,int G,int B)
{
    int x_2=x_1+L*cos(theta);
    int y_2=y_1-L*sin(theta);
    thickLineRGBA(Renderer,x_1,y_1,x_2,y_2,width,R,G,B,255);
    SDL_RenderPresent(Renderer);
}
void drawAALine(SDL_Renderer* renderer, int x1, int y1, double angle, int length, Uint8 r, Uint8 g, Uint8 b) {
    int x2 = x1 + static_cast<int>(length * cos(angle));
    int y2 = y1 + static_cast<int>(length * sin(angle));

    aalineRGBA(renderer, x1, y1, x2, y2, r, g, b, 255);
}
void scorelist(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\leaderboard.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void background1(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\background1.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void gameOver(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\gameover.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void background2(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\background2.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void background3(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\background3.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void background4(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\background4.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void preview1(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\preview1.jpg");
    SDL_Rect imageRect;
    imageRect.x = 250;
    imageRect.y = 500;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void preview2(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\preview2.jpg");
    SDL_Rect imageRect;
    imageRect.x = 500;
    imageRect.y = 500;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void preview3(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\preview3.jpg");
    SDL_Rect imageRect;
    imageRect.x = 250;
    imageRect.y = 650;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void preview4(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\preview4.jpg");
    SDL_Rect imageRect;
    imageRect.x = 500;
    imageRect.y = 650;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void settingIMG(SDL_Renderer *m_renderer) {
    SDL_Texture *image = IMG_LoadTexture(m_renderer, "E:\\cppProject\\settingIMG.jpg");
    SDL_Rect imageRect;
    imageRect.x = 0;
    imageRect.y = 0;
    SDL_QueryTexture(image, NULL, NULL, &imageRect.w, &imageRect.h);
    SDL_RenderCopy(m_renderer, image, NULL, &imageRect);

    SDL_DestroyTexture(image);
}
void subtitle(SDL_Renderer *m_renderer) {
    SDL_Texture *image2 = IMG_LoadTexture(m_renderer, "E:\\cppProject\\2.png");
    SDL_Rect image2Rect;
    image2Rect.x = 200;
    image2Rect.y = 50;
    SDL_QueryTexture(image2, NULL, NULL, &image2Rect.w, &image2Rect.h);
    SDL_RenderCopy(m_renderer, image2, NULL, &image2Rect);
    SDL_DestroyTexture(image2);
}
void play(SDL_Renderer *m_renderer , int x, int y, int w, int h) {
    SDL_Surface* homeIMGLoad = IMG_Load("E:\\cppProject\\play.png");
    SDL_Texture *homeIMG = SDL_CreateTextureFromSurface(m_renderer, homeIMGLoad);
    SDL_FreeSurface(homeIMGLoad);
    SDL_Rect homeRect;
    homeRect.x = x;
    homeRect.y = y;
    homeRect.w = w;
    homeRect.h = h;
//    SDL_QueryTexture(homeIMG, NULL, NULL, &homeRect.w, &homeRect.h);
    SDL_RenderCopy(m_renderer, homeIMG, NULL, &homeRect);
    SDL_DestroyTexture(homeIMG);
}
void leaderboard(SDL_Renderer *m_renderer) {
    SDL_Texture *leaderBoardIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\leaderboard.png");
    SDL_Rect leaderBoardRect;
    leaderBoardRect.x = 350;
    leaderBoardRect.y = 475;
    SDL_QueryTexture(leaderBoardIMG, NULL, NULL, &leaderBoardRect.w, &leaderBoardRect.h);
    SDL_RenderCopy(m_renderer, leaderBoardIMG, NULL, &leaderBoardRect);
    SDL_DestroyTexture(leaderBoardIMG);
}
void setting(SDL_Renderer *m_renderer){
    SDL_Texture *settingIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\setting.png");
    SDL_Rect settingRect;
    settingRect.x = 700;
    settingRect.y = 475;
    SDL_QueryTexture(settingIMG, NULL, NULL, &settingRect.w, &settingRect.h);
    SDL_RenderCopy(m_renderer, settingIMG, NULL, &settingRect);
    SDL_DestroyTexture(settingIMG);
}
void menu(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\menu.png");
    SDL_Rect playRect;
    playRect.x = 700;
    playRect.y = 600;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void home(SDL_Renderer *m_renderer , int x, int y, int w , int h){
    SDL_Surface* homeIMGLoad = IMG_Load("E:\\cppProject\\home.png");
    SDL_Texture *homeIMG = SDL_CreateTextureFromSurface(m_renderer, homeIMGLoad);
    SDL_FreeSurface(homeIMGLoad);
    SDL_Rect homeRect;
    homeRect.x = x;
    homeRect.y = y;
    homeRect.w = w;
    homeRect.h = h;
//    SDL_QueryTexture(homeIMG, NULL, NULL, &homeRect.w, &homeRect.h);
    SDL_RenderCopy(m_renderer, homeIMG, NULL, &homeRect);
    SDL_DestroyTexture(homeIMG);
}
void music(SDL_Renderer *m_renderer, int x, int y){
    SDL_Texture *homeIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\music.png");
    SDL_Rect homeRect;
    homeRect.x = x;
    homeRect.y = y;
    SDL_QueryTexture(homeIMG, NULL, NULL, &homeRect.w, &homeRect.h);
    SDL_RenderCopy(m_renderer, homeIMG, NULL, &homeRect);
    SDL_DestroyTexture(homeIMG);
}
void sound(SDL_Renderer *m_renderer, int x ,int y){
    SDL_Texture *homeIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\sound.png");
    SDL_Rect homeRect;
    homeRect.x = x;
    homeRect.y = y;
    SDL_QueryTexture(homeIMG, NULL, NULL, &homeRect.w, &homeRect.h);
    SDL_RenderCopy(m_renderer, homeIMG, NULL, &homeRect);
    SDL_DestroyTexture(homeIMG);
}
void minos(SDL_Renderer *m_renderer, int x, int y) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\minus.png");
    SDL_Rect playRect;
    playRect.x = x;
    playRect.y = y;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void positive(SDL_Renderer *m_renderer, int x, int y) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\plus.png");
    SDL_Rect playRect;
    playRect.x = x;
    playRect.y = y;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void leftPage(SDL_Renderer *m_renderer){
    SDL_Texture *settingIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\left.png");
    SDL_Rect settingRect;
    settingRect.x = 520;
    settingRect.y = 710;
    SDL_QueryTexture(settingIMG, NULL, NULL, &settingRect.w, &settingRect.h);
    SDL_RenderCopy(m_renderer, settingIMG, NULL, &settingRect);
    SDL_DestroyTexture(settingIMG);
}
void rightPage(SDL_Renderer *m_renderer){
    SDL_Texture *settingIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\right.png");
    SDL_Rect settingRect;
    settingRect.x = 605;
    settingRect.y = 710;
    SDL_QueryTexture(settingIMG, NULL, NULL, &settingRect.w, &settingRect.h);
    SDL_RenderCopy(m_renderer, settingIMG, NULL, &settingRect);
    SDL_DestroyTexture(settingIMG);
}
void normalModIMG(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\normal.jpg");
    SDL_Rect playRect;
    playRect.x = 100;
    playRect.y = 75;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void timerModIMG(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\timer.jpg");
    SDL_Rect playRect;
    playRect.x = 625;
    playRect.y = 75;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void randomModIMG(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\random.jpg");
    SDL_Rect playRect;
    playRect.x = 100;
    playRect.y = 375;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void survivalModIMG(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\unlimited.jpg");
    SDL_Rect playRect;
    playRect.x = 625;
    playRect.y = 375;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}
void pausePage(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "E:\\cppProject\\pausemenu.png");
    SDL_Rect playRect;
    playRect.x = 255;
    playRect.y = 0;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}

void renderText(SDL_Renderer* renderer, TTF_Font* font, const string& text, SDL_Color color, int x, int y) {
    SDL_Surface* surface = TTF_RenderText_Blended(font, text.c_str(), color);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

    SDL_Rect destRect = { x, y, surface->w, surface->h };

    // رندر کردن تکه متن روی صفحه
    SDL_RenderCopy(renderer, texture, nullptr, &destRect);

    // گرفتن اندازه صفحه و آزاد کردن حافظه
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}
void renderText2(SDL_Renderer* renderer, TTF_Font* font1, const std::string& text, int x, int y) {
    SDL_Color textColor = {255, 255, 255}; // رنگ متن (سفید)
    SDL_Surface* surface = TTF_RenderText_Solid(font1, text.c_str(), textColor);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

    SDL_Rect destRect = {x, y, surface->w, surface->h};
    SDL_RenderCopy(renderer, texture, nullptr, &destRect);

    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}
void handleInput(SDL_Event& event) {
    if (event.type == SDL_TEXTINPUT) {
        username += event.text.text;
    } else if (event.type == SDL_KEYDOWN) {
        if (event.key.keysym.sym == SDLK_BACKSPACE && !username.empty()) {
            username.pop_back();
        }
    }
}
void readUserData(std::vector<User>& users, const std::string& filename) {
    ifstream inputFile(filename);

    string line;
    while (getline(inputFile, line)) {
        istringstream iss(line);
        User currentUser;

        getline(iss, currentUser.username, ',');

        for (int i = 0; i < 4; ++i) {
            std::string temp;
            std::getline(iss, temp, ',');
            currentUser.data[i] = std::stoi(temp);
        }

        users.push_back(currentUser);
    }

    inputFile.close();  // بستن فایل پس از خواندن اطلاعات
}
void writeUserData(User users, const std::string& filename){
    // باز کردن یک فایل تکست برای نوشتن (با پارامتر ios::app برای افزودن به انتهای فایل)
    ofstream outputFile(filename, ios::app);

    // نوشتن یوزرنیم در فایل
    outputFile << users.username << "," << users.data[0] << "," << users.data[1] << "," << users.data[2] << "," << users.data[3] << endl;

    // بستن فایل
    outputFile.close();
}
bool checkLogin(vector<User>& users){
    bool foundStr = false;
    auto it = std::find_if(users.begin(), users.end(), [](const User& user) {
        return user.username == username;
    });

    if (it != users.end()) {
         foundStr = true;
    } else {
         foundStr = false;
    }
    return foundStr;
}
int findIndexByUsername(const std::vector<User>& users) {
    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i].username == username) {
            return static_cast<int>(i);  // اندیس پیدا شده را بازگردانی می‌کنیم
        }
    }
    return -1;  // اگر یافت نشد، -1 بازگردانده می‌شود
}

void ballTable(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "balltable.png");
    SDL_Rect playRect;
    playRect.x = 0;
    playRect.y = 653;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}

void background(SDL_Renderer *m_renderer) {
    SDL_Texture *playIMG = IMG_LoadTexture(m_renderer, "background.png");
    SDL_Rect playRect;
    playRect.x = 0;
    playRect.y = 0;
    SDL_QueryTexture(playIMG, NULL, NULL, &playRect.w, &playRect.h);
    SDL_RenderCopy(m_renderer, playIMG, NULL, &playRect);
    SDL_DestroyTexture(playIMG);
}

void cannonRotate(SDL_Renderer* renderer, double angle, int centerX, int centerY) {
    SDL_Surface* imageSurface = IMG_Load("cannon.png");
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, imageSurface);
    // Get image dimensions
    int imageWidth, imageHeight;
    SDL_QueryTexture(texture, nullptr, nullptr, &imageWidth, &imageHeight);

    // Set the destination rectangle (for rendering the rotated image)
    SDL_Rect destinationRect = { centerX - imageWidth / 2, centerY - imageHeight / 2, imageWidth, imageHeight };

    // Render the rotated texture
    SDL_RenderCopyEx(renderer, texture, nullptr, &destinationRect, angle, nullptr, SDL_FLIP_NONE);
    // Free resources
    SDL_FreeSurface(imageSurface);
    SDL_DestroyTexture(texture);
}

void dotLine(SDL_Renderer* renderer, double angle, int centerX, int centerY, SDL_Texture* texture) {
    int imageWidth, imageHeight;
    SDL_QueryTexture(texture, nullptr, nullptr, &imageWidth, &imageHeight);

    // Set the destination rectangle (for rendering the rotated image)
    SDL_Rect destinationRect = { centerX - imageWidth / 2, centerY - imageHeight / 2, imageWidth, imageHeight };

    // Render the rotated texture
    SDL_RenderCopyEx(renderer, texture, nullptr, &destinationRect, angle, nullptr, SDL_FLIP_NONE);
}

#endif //UNTITLED20_FUNCTIONS_H




/*if (currentState == PLAY_PAGE) {
    if (currentBackground == THEME1) background1(m_renderer);
    if (currentBackground == THEME2) background2(m_renderer);
    if (currentBackground == THEME3) background3(m_renderer);
    if (currentBackground == THEME4) background4(m_renderer);
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 24; ++j) {
            filledCircleColor(m_renderer, j*50 + 25, i*50 + 25, 25, Array[i][j][1]);
        }
    }
    home(m_renderer, 25 , 700, 75, 75);
}*/

/*                /////////شرط زیر برای رفتن از .....///////
                if (mouseX >= 500 && mouseX <= 700 &&
                    mouseY >= 400 && mouseY <= 600 && currentState == HOME_PAGE) {
                    // Change the state to the main page
                    currentState = PLAY_PAGE;
                    long long int colorID[3] = {0xff7240ef, 0xff61e5f9, 0xffaf0821};
                    for (int i = 0; i < 10; ++i) {
                        for (int j = 0; j < 24 ; ++j) {
                            int k = rand()%3;
                            Array[i][j][0] = 10*i + (j+1); // it's ball ID!
                            Array[i][j][1] = colorID[k];
                        }
                    }
                }*/