#include "functions.h"



int main(int argc, char *argv[]) {
    PageState currentState = HOME_PAGE;
    SOUND soundState = SOUND_ON;
    MUSIC musicState = MUSIC_ON;
    MUSICs currentMusic = MUSIC1;
    BACKGROUND currentBackground = THEME1;
    LOGIN accountState = WAITING_FOR_USERNAME;

/////////////////////////////////////////////////////////////////////////////////
    //Initialization of Everything
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        SDL_Log("Unable to initialize SDL: %s", SDL_GetError());
        return 1;
    }
    if (!IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG)) {
        SDL_Log("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        SDL_Log("SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
        SDL_Quit();
        return 1;
    }
    if (TTF_Init() == -1) {
        SDL_Log("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }
    //Initialization of SDL windows
    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER;
    Uint32 WND_flags = SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE;//SDL_WINDOW_BORDERLESS ;
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    SDL_Init(SDL_flags);
    //Texture for loading image
    SDL_CreateWindowAndRenderer(1200, 800, WND_flags, &m_window, &m_renderer);
    //Pass the focus to the drawing window
    SDL_RaiseWindow(m_window);
    //Get screen resolution
    SDL_DisplayMode DM;
    // SDL_SetRenderDrawColor(m_renderer, 255, 255, 255, 255);
    SDL_GetCurrentDisplayMode(0, &DM);
////////////////////////////////////////////////////////////////////////////////
    srand(time(nullptr));

    vector<User> users;
    readUserData(users, "E:\\cppProject\\untitled20\\cmake-build-debug\\scorelist.txt");

    TTF_Font* font = TTF_OpenFont("C:\\Windows\\Fonts\\Comic.ttf", 24);
    TTF_Font* font1 = TTF_OpenFont("C:\\Windows\\Fonts\\Comic.ttf", 24);
    TTF_Font* font2 = TTF_OpenFont("C:\\Windows\\Fonts\\Comic.ttf", 40);
    TTF_Font* font3 = TTF_OpenFont("C:\\Windows\\Fonts\\Arial.ttf", 20);

    Mix_Music* music1 = Mix_LoadMUS("E:\\cppProject\\music1.mp3");
    Mix_Music* music2 = Mix_LoadMUS("E:\\cppProject\\music2.mp3");
    Mix_Music* music3 = Mix_LoadMUS("E:\\cppProject\\music3.mp3");
    Mix_Music* music4 = Mix_LoadMUS("E:\\cppProject\\music4.mp3");
    Mix_PlayMusic(music1 , -1);

    Mix_Chunk* keyPress = Mix_LoadWAV("E:\\cppProject\\keyPress.mp3");
    Mix_Chunk* turnON = Mix_LoadWAV("E:\\cppProject\\turnon.mp3");
    Mix_Chunk* turnOFF = Mix_LoadWAV("E:\\cppProject\\turnoff.mp3");

    SDL_Surface* dotSurface = IMG_Load("dotline.png");
    SDL_Texture* dotTexture = SDL_CreateTextureFromSurface(m_renderer, dotSurface);
    SDL_FreeSurface(dotSurface);

    double volume = MIX_MAX_VOLUME;
    double volumeSound = MIX_MAX_VOLUME;
    double tenPercent = volume/10;
    int lengthVolume = 181;
    int lengthVolumeSound = 181;

    int indexUser = 0;
    int page = 0;
int asa=0;
int ese=0;


    double angle = 0;
    int cursorX = 0, cursorY = 0, centerXcannon = 563 + 38, centerYcannon = 660 + 59;
    double m = 0, result_deg = 0 , l = 0;   int xPosition = 0;
    double lineAngle = 0;


int em=0;
int xx=0;
int r1;
int b1;
int g1;

    vector<double> x;
    vector<double> y;
    vector<int> ran;
    int s1 = 0;
    int s = 0;
    int s2 = 0;
    double dy = 20;
    int r;
    int b;
    int g;
    int k;
    int sh = 0;

    double x1 = centerXcannon;
    double y1 = centerYcannon;
    double dx1 = 0;
    double dxy=2.9;
        int emtiaz=0;

    double dy1 = 0;
//    int z = 0;
    int t = 0;
    int d = 0;
    int v=0;
    int q=0;
    int mm = 0;
    int n = -1;
//    int s1 = 0;
//    int s = 0;
    int par[500];
    int pa = 0;
    double as = 0.5;
    double tl = 0;
    int rr = 0;
    double j;
    int ss = 0;
    int kk = 0;
    int nn = 0;
    int p_dob = 0;
    int o = 0;
    int gg = 0;
    int tt = 0;
    int ran2;
    int tamam = 0;
    int ta = 0;
    int nej = 0;
    int mark1[500];
    int soghot[500];
    int jado[500];
    for (int i = 0; i < 500; ++i) {
        jado[i] = 0;
    }

    for (int i = 0; i < 500; ++i) {
        soghot[i] = 0;
    }

    for (int i = 0; i < 500; ++i) {
        mark1[i] = 0;
    }

    vector<int> jav;
    vector<int> nav;

    int mark[500];
    for (int i = 0; i < 500; ++i) {
        mark[i] = 0;
    }

    for (int jj = 0; jj < 3; ++jj) {
        for (int i = 0; i < 30; ++i) {
//             if(rand()%10!=0) {
            k = rand() % 7;
            if (k==6)
            {
                if (rand()%4==0)
                {
                    k=6;
                }
                if (rand()%4==1)
                {
                    k=1;
                }
               if (rand()%4==2)
                {
                    k=2;
                }
                if (rand()%4==3)
                {
                    k=3;
                }
            }
            ran.push_back(k);
            x.push_back(20 + 40 * i);
            y.push_back(-100 + 35 * (2*jj));
            ++sh;
        }
//        }
    }
/////////////////////////
    for (int jj = 0; jj < 3; ++jj) {
        for (int i = 0; i < 29; ++i) {
//             if(rand()%10!=0) {
            k = rand() % 7;
            if (k==6)
            {
                if (rand()%4==0)
                {
                    k=6;
                }
                if (rand()%4==1)
                {
                    k=1;
                }
                 if (rand()%4==2)
                {
                    k=2;
                }
                 if (rand()%4==3)
                {
                    k=3;
                }
            }
            ran.push_back(k);
            x.push_back(40 + 40 * i);
            y.push_back(-100+ 35 * (2*jj+1));
            ++sh;
        }
//        }
    }











    bool pauseMenu = false;

///////////////Program Section...//////////////////////
    bool quit = false;
    SDL_Event e;

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            int mouseX, mouseY;
            if (e.type == SDL_QUIT) {
                quit = true;
            } else if (e.type == SDL_MOUSEBUTTONDOWN) {
                SDL_GetMouseState(&mouseX, &mouseY);

                // Check if the mouse click is on the icon
                /////////شرط زیر برای رفتن از صفحه امتیازات یا صفحه تنظیمات یا صفحه منو یا صفحات مود ها به صفحه خانه با زدن روی دکمه "خانه" است///////
                if (mouseX >= 50 && mouseX <= 200 &&
                    mouseY >= 50 && mouseY <= 200 && (currentState == LEADERBOARD_PAGE || currentState == SETTING_PAGE)) {
                    // Change the state to the main page
                    currentState = HOME_PAGE;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                if (mouseX >= 550 && mouseX <= 650 &&
                    mouseY >= 600 && mouseY <= 700 && (currentState == LOSE_PAGE)) {
                    // Change the state to the main page
                    currentState = HOME_PAGE;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                if (mouseX >= 25 && mouseX <= 100 &&
                    mouseY >= 700 && mouseY <= 775 && currentState == MENU_PAGE) {
                    // Change the state to the main page
                    currentState = HOME_PAGE;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                ////////////شرط زیر کاربر را به گیم مود های مختلف هدایت می کند////////
                if (currentState == MENU_PAGE && accountState == LOGED_IN) {
                    if (mouseX >= 100 && mouseX <= 575 &&
                        mouseY >= 75 && mouseY <= 300) { currentState = NORMAL_MODE;  angle = 0;   if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);}
                    if (mouseX >= 625 && mouseX <= 1100 &&
                        mouseY >= 75 && mouseY <= 300) { currentState = TIME_MODE;      if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);}
                    if (mouseX >= 100 && mouseX <= 575 &&
                        mouseY >= 375 && mouseY <= 600) { currentState = RANDOM_MODE;   if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);}
                    if (mouseX >= 625 && mouseX <= 1100 &&
                        mouseY >= 375 && mouseY <= 600) { currentState = SURVIVAL_MODE; if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);}
                }
                if ((currentState == NORMAL_MODE || currentState == TIME_MODE || currentState == RANDOM_MODE || currentState == SURVIVAL_MODE) && pauseMenu) {
                    if (mouseX >= 525 && mouseX <= 625 &&
                        mouseY >= 600 && mouseY <= 700) { pauseMenu = false; if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);}
                    if (mouseX >= 700 && mouseX <= 800 &&
                        mouseY >= 600 && mouseY <= 700) {
                        currentState = MENU_PAGE;
                        pauseMenu = false;
                        if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                    }
                    if (mouseX >= 400 && mouseX <= 500 &&
                        mouseY >= 350 && mouseY <= 450) {
                        if (musicState == MUSIC_ON) {
                            musicState = MUSIC_OFF;
                            Mix_PauseMusic();
                            if (soundState == SOUND_ON) Mix_PlayChannel(-1, turnOFF, 0);
                        }
                        else {
                            musicState = MUSIC_ON;
                            if (currentMusic == MUSIC1) Mix_PlayMusic(music1, -1);
                            if (currentMusic == MUSIC2) Mix_PlayMusic(music2, -1);
                            if (currentMusic == MUSIC3) Mix_PlayMusic(music3, -1);
                            if (currentMusic == MUSIC4) Mix_PlayMusic(music4, -1);
                            if (soundState == SOUND_ON) Mix_PlayChannel(-1, turnON, 0);
                        }
                    }
                    if (mouseX >= 530 && mouseX <= 580 &&
                        mouseY >= 380 && mouseY <= 430 && volume >= 1){
                        volume-=tenPercent;
                        lengthVolume-= 18;
                        cout << volume << ", " << lengthVolume << endl;
                        Mix_VolumeMusic(int(volume));
                        if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                    }
                    if (mouseX >= 760 && mouseX <= 810 &&
                        mouseY >= 380 && mouseY <= 430 && volume < MIX_MAX_VOLUME){
                        volume+=tenPercent;
                        cout << volume << ", " << lengthVolume << endl;
                        lengthVolume+= 18;
                        Mix_VolumeMusic(int(volume));
                        if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                    }

                    /////////شرط زیر برای قطع یا وصل کردن صدا از طریق زدن روی دکمه "صدا" است///////
                    if (mouseX >= 370 && mouseX <= 470 &&
                        mouseY >= 225 && mouseY <= 325) {
                        if (soundState == SOUND_ON) {
                            soundState = SOUND_OFF;
                        }
                        else {
                            soundState = SOUND_ON;
                        }
                    }
                    /////////شرط زیر برای کم کردن صدا با زدن روی دکمه "-" است///////
                    if (mouseX >= 500 && mouseX <= 550 &&
                        mouseY >= 255 && mouseY <= 305 && volumeSound >= 1) {
                        // Change the state to the main page18
                        volumeSound-=tenPercent;
                        lengthVolumeSound-= 18;
                        cout << volumeSound << ", " << lengthVolumeSound << endl;
                        Mix_Volume(-1, volumeSound);
                        if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                    }
                    /////////شرط زیر برای افزایش صدا با زدن روی دکمه "+" است///////
                    if (mouseX >= 730 && mouseX <= 780 &&
                        mouseY >= 255 && mouseY <= 305 && volumeSound < MIX_MAX_VOLUME) {
                        // Change the state to the main page
                        volumeSound+=tenPercent;
                        cout << volumeSound << ", " << lengthVolumeSound << endl;
                        lengthVolumeSound+= 18;
                        Mix_Volume(-1, volumeSound);
                        if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                    }

                }

                /////////شرط زیر برای رفتن از صفحه خانه به صفحه انتخاب مود ها با زدن روی دکمه "play" است///////
                if (mouseX >= 500 && mouseX <= 700 &&
                    mouseY >= 400 && mouseY <= 600 && currentState == HOME_PAGE) {
                    // Change the state to the main page
                    currentState = MENU_PAGE;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای رفتن از صفحه خانه به صفحه جدول امتیازات با زدن روی دکمه "leaderBoard" است///////
                if (mouseX >= 350 && mouseX <= 500 &&
                    mouseY >= 475 && mouseY <= 625 && currentState == HOME_PAGE) {
                    // Change the state to the main page
                    currentState = LEADERBOARD_PAGE;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای رفتن از صفحه خانه به صفحه تنظیمات با زدن روی دکمه "تنظیمات" است///////
                if (mouseX >= 700 && mouseX <= 850 &&
                    mouseY >= 475 && mouseY <= 625 && currentState == HOME_PAGE) {
                    // Change the state to the main page
                    currentState = SETTING_PAGE;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای قطع یا وصل کردن موزیک از طریق زدن روی دکمه "موزیک" است///////
                if (mouseX >= 50 && mouseX <= 150 &&
                    mouseY >= 350 && mouseY <= 450 && currentState == SETTING_PAGE) {
                        if (musicState == MUSIC_ON) {
                            musicState = MUSIC_OFF;
                            Mix_PauseMusic();
                            if (soundState == SOUND_ON) Mix_PlayChannel(-1, turnOFF, 0);
                        }
                        else {
                            musicState = MUSIC_ON;
                            if (currentMusic == MUSIC1) Mix_PlayMusic(music1, -1);
                            if (currentMusic == MUSIC2) Mix_PlayMusic(music2, -1);
                            if (currentMusic == MUSIC3) Mix_PlayMusic(music3, -1);
                            if (currentMusic == MUSIC4) Mix_PlayMusic(music4, -1);
                            if (soundState == SOUND_ON) Mix_PlayChannel(-1, turnON, 0);
                        }
                }
                /////////شرط زیر برای قطع یا وصل کردن صدا از طریق زدن روی دکمه "صدا" است///////
                if (mouseX >= 50 && mouseX <= 150 &&
                    mouseY >= 225 && mouseY <= 325 && currentState == SETTING_PAGE) {
                    if (soundState == SOUND_ON) {
                        soundState = SOUND_OFF;
                    }
                    else {
                        soundState = SOUND_ON;
                    }
                }
                /////////شرط زیر برای کم کردن موزیک با زدن روی دکمه "-" است///////
                if (mouseX >= 220 && mouseX <= 270 &&
                    mouseY >= 380 && mouseY <= 430 && currentState == SETTING_PAGE && volume >= 1) {
                    // Change the state to the main page18
                    volume-=tenPercent;
                    lengthVolume-= 18;
                    Mix_VolumeMusic(int(volume));
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای افزایش موزیک با زدن روی دکمه "+" است///////
                if (mouseX >= 450 && mouseX <= 500 &&
                    mouseY >= 380 && mouseY <= 430 && currentState == SETTING_PAGE && volume < MIX_MAX_VOLUME) {
                    // Change the state to the main page
                    volume+=tenPercent;
                    lengthVolume+= 18;
                    Mix_VolumeMusic(int(volume));
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای کم کردن صدا با زدن روی دکمه "-" است///////
                if (mouseX >= 220 && mouseX <= 270 &&
                    mouseY >= 255 && mouseY <= 305 && currentState == SETTING_PAGE && volumeSound >= 1) {
                    // Change the state to the main page18
                    volumeSound-=tenPercent;
                    lengthVolumeSound-= 18;
                    cout << volumeSound << ", " << lengthVolumeSound << endl;
                    Mix_Volume(-1, volumeSound);
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای افزایش صدا با زدن روی دکمه "+" است///////
                if (mouseX >= 450 && mouseX <= 500 &&
                    mouseY >= 255 && mouseY <= 305 && currentState == SETTING_PAGE && volumeSound < MIX_MAX_VOLUME) {
                    // Change the state to the main page
                    volumeSound+=tenPercent;
                    cout << volumeSound << ", " << lengthVolumeSound << endl;
                    lengthVolumeSound+= 18;
                    Mix_Volume(-1, volumeSound);
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای اجرای موزیک اول است با زدن روی متن music1///////
                if (mouseX >= 50 && mouseX <= 150 &&
                    mouseY >= 500 && mouseY <= 540 && currentState == SETTING_PAGE && currentMusic != MUSIC1) {
                    currentMusic = MUSIC1;
                    if (musicState == MUSIC_ON) Mix_PlayMusic(music1 , -1);
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای اجرای موزیک دوم است با زدن روی متن music2///////
                if (mouseX >= 50 && mouseX <= 150 &&
                    mouseY >= 540 && mouseY <= 580 && currentState == SETTING_PAGE && currentMusic != MUSIC2) {
                    currentMusic = MUSIC2;
                    if (musicState == MUSIC_ON) Mix_PlayMusic(music2 , -1);
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای اجرای موزیک سوم است با زدن روی متن music3///////
                if (mouseX >= 50 && mouseX <= 150 &&
                    mouseY >= 580 && mouseY <= 620 && currentState == SETTING_PAGE && currentMusic != MUSIC3) {
                    currentMusic = MUSIC3;
                    if (musicState == MUSIC_ON) Mix_PlayMusic(music3 , -1);
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای اجرای موزیک چهارم است با زدن روی متن music4///////
                if (mouseX >= 50 && mouseX <= 150 &&
                    mouseY >= 620 && mouseY <= 660 && currentState == SETTING_PAGE && currentMusic != MUSIC4) {
                    currentMusic = MUSIC4;
                    if (musicState == MUSIC_ON) Mix_PlayMusic(music4 , -1);
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای تعویض تم اول است با زدن روی عکس اول///////
                if (mouseX >= 250 && mouseX <= 450 &&
                    mouseY >= 500 && mouseY <= 633 && currentState == SETTING_PAGE && currentBackground != THEME1) {
                    currentBackground = THEME1;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای تعویض تم دوم است با زدن روی عکس دوم///////
                if (mouseX >= 500 && mouseX <= 700 &&
                    mouseY >= 500 && mouseY <= 633 && currentState == SETTING_PAGE && currentBackground != THEME2) {
                    currentBackground = THEME2;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای تعویض تم سوم است با زدن روی عکس سوم///////
                if (mouseX >= 250 && mouseX <= 450 &&
                    mouseY >= 650 && mouseY <= 783 && currentState == SETTING_PAGE && currentBackground != THEME3) {
                    currentBackground = THEME3;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                /////////شرط زیر برای تعویض تم چهارم است با زدن روی عکس چهارم///////
                if (mouseX >= 500 && mouseX <= 700 &&
                    mouseY >= 650 && mouseY <= 783 && currentState == SETTING_PAGE && currentBackground != THEME4) {
                    currentBackground = THEME4;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                if (mouseX >= 520 && mouseX <= 595 &&
                    mouseY >= 710 && mouseY <= 785 && currentState == LEADERBOARD_PAGE && page > 0) {
                    page--;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }
                if (mouseX >= 605 && mouseX <= 680 &&
                    mouseY >= 710 && mouseY <= 785 && currentState == LEADERBOARD_PAGE && page < ceil(double(users.size())/6)-1) {
                    page++;
                    if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
                }

            }
            if (currentState == MENU_PAGE) {
                handleInput(e);
                if (e.type == SDL_KEYUP && e.key.keysym.scancode != SDL_SCANCODE_RETURN) {
                    accountState = WAITING_FOR_USERNAME;
                }
                if (e.type == SDL_KEYUP && e.key.keysym.sym == SDLK_RETURN) {
                    if (!checkLogin(users)) {

                        users.resize(0);
                        User newUser;
                        newUser.username = username;
                        newUser.data[0] = 0;
                        newUser.data[1] = 0;
                        newUser.data[2] = 0;
                        newUser.data[3] = 0;
                        writeUserData(newUser, "E:\\cppProject\\untitled20\\cmake-build-debug\\scorelist.txt");
                        readUserData(users, "E:\\cppProject\\untitled20\\cmake-build-debug\\scorelist.txt");

                        accountState = SIGNED_UP;
                    }
                    else {
                        accountState = LOGED_IN;
                        indexUser = findIndexByUsername(users);
//                        cout << users[indexUser].data[0] << endl;
//                        cout << users[indexUser].data[1] << endl;
                        cout << users[indexUser].data[2] << endl;
                        cout << users[indexUser].username << endl;
                        cout << endl;

                    }
                }
            }
            if ((currentState == NORMAL_MODE || currentState == TIME_MODE || currentState == RANDOM_MODE || currentState == SURVIVAL_MODE) && (e.type == SDL_KEYUP && e.key.keysym.sym == SDLK_ESCAPE)) {
                if (pauseMenu) pauseMenu = false;
                else           pauseMenu = true;
                if (soundState == SOUND_ON) Mix_PlayChannel(-1, keyPress, 0);
            }

            if (currentState == RANDOM_MODE && e.type == SDL_MOUSEMOTION && !pauseMenu){
                    cursorX = e.motion.x;
                    cursorY = e.motion.y;

                    double deltaX = fabs(centerXcannon - cursorX);
                    double deltaY = fabs(centerYcannon - cursorY);
                    l = deltaY * centerXcannon / deltaX;

                    if (cursorX > 600) xPosition = 1200;
                    else xPosition = 0;

                    m = double(cursorY - centerYcannon) / (cursorX - centerXcannon);
                    double result_rad = atan(m);

                    if (cursorX > 600) lineAngle = 180*(atan(-m) + M_PI)/M_PI;
                    else lineAngle = 180*atan(-m)/M_PI;

                    if (cursorX == centerXcannon && cursorY == centerYcannon) result_deg = 0;
                    else if (cursorX > 600) result_deg = result_rad * 180 / M_PI + 90;
                    else result_deg = result_rad * 180 / M_PI + 270;
            }

            if(rr==0&&xx==1){
                if (currentState == RANDOM_MODE && e.type == SDL_MOUSEBUTTONDOWN && !pauseMenu) {
                    SDL_GetMouseState(&mouseX, &mouseY);

                    j = abs(atan((y1 - mouseY) / (mouseX - x1)));
                    if (mouseX > x1) {
                        dx1 = abs(dxy * cos(j));
                        dy1 = abs(dxy * sin(j));
                    }
                    if (mouseX < x1) {
                        dx1 = -abs(dxy * cos(j));
                        dy1 = abs(dxy * sin(j));
                    }
                    if (mouseX == x1) {
                        dx1 = 0;
                        dy1 = abs(dxy * sin(j));
                    }
                    rr = 1;

                }
                // }
            }
            if (e.type == SDL_KEYUP && e.key.keysym.sym == SDLK_SPACE) {
                asa=ran2;
                ese=par[pa];
                ran2=ese;
                par[pa]=asa;
            }

        }


        // Clear the screen
        SDL_SetRenderDrawColor(m_renderer, 0, 0, 0, 255);
        SDL_RenderClear(m_renderer);

        if (pauseMenu) { dy = 0; dxy = 0; }
        else { dy = 0.5; dxy = 2.9; }






        ++v;
//dxy=2.8;
        ///////////////////////
        if (s1 == 0) {
            q = 0;
            d = 0;
            jav.erase(jav.begin(), jav.end());
            s2 = 0;
            s = 0;
//                s1=0;
//            tl = 0;
            for (int ii = 0; ii < sh; ++ii) {
                soghot[ii] = 0;
                jado[ii] = 0;
            }
        }
        /////////////
        if (gg == 0) {
            par[pa] = rand() % 1;
            ran2=rand()%6;
            gg = 1;
        }


//        if (e.type == SDL_KEYUP && e.key.keysym.sym == SDLK_SPACE) {
//            asa=ran2;
//            ese=par[pa];
//            ran2=ese;
//            par[pa]=asa;
//        }
//







        if (currentState != LEADERBOARD_PAGE) {
            page = 0;
        }
        // Draw the current page based on the state
        if (currentState == HOME_PAGE) {
            // Draw the main page
            // ...
            if (currentBackground == THEME1) background1(m_renderer);
            if (currentBackground == THEME2) background2(m_renderer);
            if (currentBackground == THEME3) background3(m_renderer);
            if (currentBackground == THEME4) background4(m_renderer);
            subtitle(m_renderer);
            play(m_renderer, 500, 400, 200, 200);
            setting(m_renderer);
            leaderboard(m_renderer);
//            filledPieRGBA(m_renderer, 400, 300, 50, 180,360, 0, 0, 255, 255);
        }
        if (currentState == LEADERBOARD_PAGE) {
            // Draw the other page
            // ...
            SDL_Color textColor = {0, 0, 0}; // رنگ متن (سفید)
            scorelist(m_renderer);
            home(m_renderer, 25, 25 , 100, 100);
            leftPage(m_renderer);
            rightPage(m_renderer);
            renderText(m_renderer, font2, "PLAYERS SCORE!", textColor, 450, 40);
            renderText(m_renderer, font, "NORMAL          TIMER         RANDOM       SURVIVAL", textColor, 455, 175);
            renderText(m_renderer, font, "USERNAMEs", textColor, 200, 175);
            int j = 1;
            int numberUsers = users.size();

            if (numberUsers - 6*(page) > 6) {
                for (size_t k = 6 * page; k < 6 * (page+1); ++k) {
                    renderText(m_renderer, font, users[k].username, textColor, 200, 175 + 77 * j);
                    for (int i = 0; i < 4; ++i) {
                        renderText(m_renderer, font, to_string(users[k].data[i]), textColor, 450 + 160 * i,
                                   175 + 77 * j);
                    }
                    j++;
                }
            }
            else {
                for (size_t k = 6*page; k < numberUsers; ++k) {
                    renderText(m_renderer, font, users[k].username, textColor, 200, 175 + 77 * j);
                    for (int i = 0; i < 4; ++i) {
                        renderText(m_renderer, font, to_string(users[k].data[i]), textColor, 450 + 160 * i,
                                   175 + 77 * j);
                    }
                    j++;
                }
            }


        }
        if (currentState == SETTING_PAGE) {

            // Draw the other page
            // ...
            settingIMG(m_renderer);
            SDL_Color textColor = {255, 255, 255}; // رنگ متن (سفید)
            renderText(m_renderer, font, "MUSIC 1", textColor, 50, 500);
            renderText(m_renderer, font, "MUSIC 2", textColor, 50, 540);
            renderText(m_renderer, font, "MUSIC 3", textColor, 50, 580);
            renderText(m_renderer, font, "MUSIC 4", textColor, 50, 620);

            if (currentMusic == MUSIC1) renderText(m_renderer, font, ">>", textColor, 25, 500);
            if (currentMusic == MUSIC2) renderText(m_renderer, font, ">>", textColor, 25, 540);
            if (currentMusic == MUSIC3) renderText(m_renderer, font, ">>", textColor, 25, 580);
            if (currentMusic == MUSIC4) renderText(m_renderer, font, ">>", textColor, 25, 620);

            if (currentBackground == THEME1) renderText(m_renderer, font, ">>", textColor, 225, 550);
            if (currentBackground == THEME2) renderText(m_renderer, font, ">>", textColor, 475, 550);
            if (currentBackground == THEME3) renderText(m_renderer, font, ">>", textColor, 225, 700);
            if (currentBackground == THEME4) renderText(m_renderer, font, ">>", textColor, 475, 700);

            preview1(m_renderer);
            preview2(m_renderer);
            preview3(m_renderer);
            preview4(m_renderer);

            home(m_renderer, 50, 50, 150, 150);

            music(m_renderer , 50 , 350);
            minos(m_renderer, 220 , 380);
            positive(m_renderer, 450 , 380);
            my_line(m_renderer, 270, 405 , lengthVolume, 0, 15, 255, 255, 255);
            if (musicState == MUSIC_OFF) {
                my_line(m_renderer, 75, 425, 80, 3.14 / 4, 5, 149, 0, 82);
            }


            sound(m_renderer, 50 , 225);
            minos(m_renderer, 220 , 255);
            positive(m_renderer, 450 , 255);
            my_line(m_renderer, 270, 280 , lengthVolumeSound, 0, 15, 255, 255, 255);
            if (soundState == SOUND_OFF) {
                my_line(m_renderer, 75, 300, 80, 3.14 / 4, 5, 149, 0, 82);
            }

        }
        if (currentState == MENU_PAGE) {
            SDL_Color textColor = {255, 255, 255}; // رنگ متن (سفید)
            SDL_Color textColor2 = {255, 0, 50}; // رنگ متن (سفید)

            if (currentBackground == THEME1) background1(m_renderer);
            if (currentBackground == THEME2) background2(m_renderer);
            if (currentBackground == THEME3) background3(m_renderer);
            if (currentBackground == THEME4) background4(m_renderer);

            renderText(m_renderer, font, "NORMAL MODE", textColor, 100, 35);
            renderText(m_renderer, font, "TIMER MODE", textColor, 625, 35);
            renderText(m_renderer, font, "RANDOM MODE", textColor, 100, 335);
            renderText(m_renderer, font, "SURVIVAL MODE", textColor, 625, 335);
            renderText(m_renderer, font3, ">>You can't play MODs without logging in<<", textColor, 290, 650);
            if (accountState == WAITING_FOR_USERNAME) renderText(m_renderer, font, "Enter Username (For Login or Signup) ...", textColor2, 720, 700);
            if (accountState == LOGED_IN) { renderText(m_renderer, font, "You Loged in! Now enjoy playing!", textColor2, 720, 700); }
            if (accountState == SIGNED_UP){renderText(m_renderer, font, "Your account been created. Now login", textColor2, 720, 700);}

            normalModIMG(m_renderer);
            timerModIMG(m_renderer);
            randomModIMG(m_renderer);
            survivalModIMG(m_renderer);
            home(m_renderer, 25 , 700, 75, 75);
            rectangleRGBA(m_renderer, 280, 700, 700,740, 255, 255, 255, 255);
            renderText2(m_renderer, font1, "Username: " + username, 300, 700);
        }
        if (currentState == NORMAL_MODE) {

        }
        if (currentState == TIME_MODE) {
            if (currentBackground == THEME1) background1(m_renderer);
            if (currentBackground == THEME2) background2(m_renderer);
            if (currentBackground == THEME3) background3(m_renderer);
            if (currentBackground == THEME4) background4(m_renderer);
            SDL_Color textColor = {255, 255, 255}; // رنگ متن (سفید)
            renderText(m_renderer, font, "TIME MOD!", textColor, 600, 100);
        }
        if (currentState == RANDOM_MODE) {

            xx = 1;
            background(m_renderer);
            ballTable(m_renderer);

            if (result_deg <= 84.25 || result_deg >= 275.7) {
                dotLine(m_renderer, lineAngle, xPosition, centerYcannon - l, dotTexture);
                dotLine(m_renderer, result_deg+ 180 + 90, centerXcannon, centerYcannon, dotTexture);
                cannonRotate(m_renderer, result_deg, centerXcannon, centerYcannon);
            }
            else if (result_deg <= 180 && result_deg > 84.25){
                dotLine(m_renderer, 185.9, xPosition, 660, dotTexture);
                dotLine(m_renderer, 174.3 + 180, centerXcannon, centerYcannon, dotTexture);
                cannonRotate(m_renderer, 84, centerXcannon, centerYcannon);

            }
            else if (result_deg >= 180 && result_deg < 275.7){
                dotLine(m_renderer, -5.71, xPosition, 660, dotTexture);
                dotLine(m_renderer,365.6 + 180 , centerXcannon, centerYcannon, dotTexture);
                cannonRotate(m_renderer, 275, centerXcannon, centerYcannon);
            }
            filledEllipseRGBA(m_renderer, centerXcannon,centerYcannon, 20, 20, 255, 255 , 255, 255);



            if (par[pa] == 0) {
                r = 0;
                b = 0;
                g = 255;
            }
            if (par[pa] == 1) {
                r = 255;
                b = 0;
                g = 0;
            }
            if (par[pa] == 2) {
                r = 0;
                b = 255;
                g = 0;
            }
            if (par[pa] == 3) {
                r = 200;
                b = 0;
                g = 200;
            }
            if (par[pa] == 4) {
                r = 200;
                b = 200;
                g = 0;
            }
            if (par[pa] == 5) {
                r = 0;
                b = 200;
                g = 200;
            }

            if (ran2 == 0) {
                r1 = 0;
                b1 = 200;
                g1 = 200;
            }
            if (ran2 == 1) {
                r1 = 0;
                b1 = 200;
                g1 = 200;
            }
            if (ran2==2 ) {
                r1 = 0;
                b1 = 200;
                g1 = 200;
            }
            if (ran2 == 3) {
                r1 = 0;
                b1 = 200;
                g1 = 200;
            }
            if (ran2 == 4) {
                r1 = 0;
                b1 = 200;
                g1 = 200;
            }
            if (ran2 == 5) {
                r1 = 0;
                b1 = 200;
                g1 = 200;
            }









/////////////////////////////////
            if (mm == 0) {
                ellipse(m_renderer, x1, y1, 20, 20, r, g, b, 1);
                ellipse(m_renderer, 521, 762, 20, 20, r1, g1, b1, 1);

            }
//////////////////
            if (p_dob == 1) {
                p_dob = 0;
                if (tt == 0) {
                    ++pa;
                    par[pa] = ran2;
                    ran2=rand()%6;
                    tt = 1;
                }

                for (int i = 0; i < 500; ++i) {
                    mark1[i] = 0;
                }
                tt = 0;
                t = 0;
                x1 = centerXcannon;
                y1 = centerYcannon;
                dx1 = 0;
                dxy=5;
                dy1 = 0;
                n = -1;
                rr = 0;
                nn = 0;
//            ss = 0;
                mm = 0;
                kk = 0;
                nej = 0;
            }

/////////////////////////////
            y1 -= dy1;
            x1 += dx1;
            if ((x1 >= 1178 && x1 <= 1182) || (x1 < 23 && x1 > 17)) {
                dx1 = -dx1;
            }
            if (y1 < 30+v*dy) {
                dy1 = 0;
                dx1 = 0;
                dxy=0;
                y.push_back(y1);
                x.push_back(x1);

                p_dob = 1;
            }


            if (t == 0) {
                for (int i = 0; i < sh; i++) {
                    if ((((y1 - y[i]) * (y1 - y[i])) + ((x1 - x[i]) * (x1 - x[i]))) > 1500 &&
                        (((y1 - y[i]) * (y1 - y[i]) + (x1 - x[i]) * (x1 - x[i])) < 1740) && mark[i] == 0) {
                        p_dob = 1;
                        if (ran[i] == par[pa]) {
                            dxy= 0;
//                        dy1 = 0;
//                        dx1 = 0;
                            mm = 1;
                            n = i;
                            t = 2;
                            break;
                        }
                        if (t == 0)
                            t = 1;
                    }
                }
            }

            if (t == 1) {
                for (int i = 0; i < sh; i++) {
                    if ((((y1 - y[i]) * (y1 - y[i])) + ((x1 - x[i]) * (x1 - x[i]))) >= 1500 &&
                        (((y1 - y[i]) * (y1 - y[i]) + (x1 - x[i]) * (x1 - x[i])) <= 1740) && mark[i] == 0) {
                        p_dob = 1;
                        if (ran[i] != par[pa]) {
                            dxy = 0;
                            dy1 = 0;
                            dx1 = 0;
                            mm = 1;
                            x.push_back(x1);
                            y.push_back(y1);
                            x1=600;
                            y1=730;
                            ran.push_back(par[pa]);
                            ++sh;
                            t = 2;
                            break;
                        }
                    }

                }

            }

///////////////////////////////\
///

            if (n != -1) {
                p_dob = 1;
                jav.push_back(n);
                if (nn == 0) {
                    mark[n] = 1;
                    mark1[n] = 1;
                }
                for (int ii = 0; ii < jav.size(); ++ii) {
                    for (int i = 0; i < sh; ++i) {
                        if ((((x[jav[ii]] - x[i]) * (x[jav[ii]] - x[i]) + (y[jav[ii]] - y[i]) * (y[jav[ii]] - y[i])) <
                             1740 &&
                             ((x[jav[ii]] - x[i]) * (x[jav[ii]] - x[i]) + (y[jav[ii]] - y[i]) * (y[jav[ii]] - y[i])) >
                             1500) && mark[i] == 0 && ran[jav[ii]] == ran[i]) {
                            jav.push_back(i);
                            mark[i] = 1;
                            mark1[i] = 1;
                        }
                    }
                }
            }

            ///////////////////////////////////
            if (jav.size() < 2 && jav.size() > 0) {

                x.push_back(x1);
                y.push_back(y1);
                ++sh;
                x1=600;
                y1=730;
                dxy=0;
                ran.push_back(par[pa]);
                mark[n] = 0;
                mark[sh] = 0;


            }
////////////////////////////////////////////////////////
            if (s2==0) {
                if (jav.size() > 1) {
                    s = 1;
                    s2=1;
                }
            }

            if (s==1) {
                s=0;
                for (int i = 0; i < sh; ++i) {
                    if (y[i] < 30+v*dy && mark[i] == 0) {
                        soghot[i] = 1;

                    }
                }
                for (int ii = 0; ii < 10 * sh; ++ii) {
                    for (int i = 0; i < sh; ++i) {
                        if (soghot[i] == 1 && jado[i] == 0 && mark[i] == 0) {
                            jado[i] = 1;
                            for (int l = 0; l < sh; ++l) {
                                if (sqrt((y[i] - y[l]) * (y[i] - y[l]) + (x[i] - x[l]) * (x[i] - x[l])) < 43 &&
                                    sqrt((y[i] - y[l]) * (y[i] - y[l]) + (x[i] - x[l]) * (x[i] - x[l])) > 37 &&
                                    soghot[l] == 0 && mark[l] == 0) {
                                    soghot[l] = 1;
//                                s=1;
                                }
                            }
                        }
//            i=0;
                    }
                }

                for (int i = 0; i < sh; ++i) {
                    if (soghot[i] == 0&&mark[i]==0) {
                        soghot[i] = 2;
                        ++d;
                    }
                }
            }
////////////////////////////////////////////////////
            for (int i = 0; i < sh; ++i) {
//            if (d==1) {
                if (soghot[i] == 2 && mark[i] == 0) {
                    s1=1;
                    y[i] += 10;
//                tl += 0.1;
                    if (y[i] > 660) {
                        s1 = 0;
                        mark[i] = 1;
//
                    }
//
                }
                ////////////////////
                if (y[i] < 660) {
                    y[i] += dy;
                    if (mark[i] != 1) {

                        if (ran[i] == 0) {
                            r = 0;
                            b = 0;
                            g = 255;
                        }
                        if (ran[i] == 1) {
                            r = 255;
                            b = 0;
                            g = 0;
                        }
                        if (ran[i] == 2) {
                            r = 0;
                            b = 255;
                            g = 0;
                        }
                        if (ran[i] == 3) {
                            r = 200;
                            b = 0;
                            g = 200;
                        }
                        if (ran[i] == 4) {
                            r = 200;
                            b = 200;
                            g = 0;
                        }
                        if (ran[i] == 5) {
                            r = 0;
                            b = 200;
                            g = 200;
                        }
                        if (ran[i] == 6) {
                            r = 0;
                            b = 0;
                            g = 0;
                        }




                        ellipse(m_renderer, x[i], y[i], 20, 20, r, g, b, 1);

                    }
                }
            }
            for (int i = 0; i < sh; ++i) {
                if (mark[i]==1)
                {
                    ++em;
                }
            }
            if (em!=0) {
                emtiaz = 50 * (em + 1);
                em = 0;
            }
            for (int i = 0; i < sh; ++i) {
                if (y[i]>660&&mark[i]==0)
                {
                    currentState = LOSE_PAGE;
                    break;
                }
            }


            string score = to_string(emtiaz);
            SDL_Color textColor = {255, 255, 255}; // رنگ متن (سفید)
            renderText(m_renderer, font, score, textColor, 720, 745);

        }
        if (currentState == SURVIVAL_MODE) {
            if (currentBackground == THEME1) background1(m_renderer);
            if (currentBackground == THEME2) background2(m_renderer);
            if (currentBackground == THEME3) background3(m_renderer);
            if (currentBackground == THEME4) background4(m_renderer);
            SDL_Color textColor = {255, 255, 255}; // رنگ متن (سفید)
            renderText(m_renderer, font, "SURVIVAL MODE!", textColor, 600, 100);
        }
        if (currentState == LOSE_PAGE){
            gameOver(m_renderer);
            home(m_renderer, 550, 600, 100, 100);
        }
        if (pauseMenu) {
            pausePage(m_renderer);

            menu(m_renderer);
            play(m_renderer, 525 , 600 , 100 , 100);

            sound(m_renderer, 370 , 225);
            minos(m_renderer, 500 , 255);
            positive(m_renderer, 730 , 255);
            my_line(m_renderer, 550, 280 , lengthVolumeSound, 0, 15, 255, 255, 255);
            if (soundState == SOUND_OFF) {
                my_line(m_renderer, 395, 300, 80, 3.14 / 4, 5, 149, 0, 82);
            }

            music(m_renderer , 400 , 350);
            minos(m_renderer, 530 , 380);
            positive(m_renderer, 760 , 380);
            my_line(m_renderer, 580, 405 , lengthVolume, 0, 15, 255, 255, 255);
            if (musicState == MUSIC_OFF) {
                my_line(m_renderer, 425, 425, 80, 3.14 / 4, 5, 149, 0, 82);
            }
        }

        if (currentState != RANDOM_MODE){
            em=0;
            xx=0;
            x.erase(x.begin(),x.end());
            y.erase(y.begin(),y.end());
            ran.erase(ran.begin(),ran.end());

            s1 = 0;
            s = 0;
            s2 = 0;
            dy = 0.5;
            sh = 0;
            x1 = centerXcannon;
            y1 = centerYcannon;
            dx1 = 0;
            dxy=2.9;

            dy1 = 0;
//    int z = 0;
            t = 0;
            d = 0;
            v=0;
            q=0;
            mm = 0;
            n = -1;
//    int s1 = 0;
//    int s = 0;
            emtiaz = 0;
            par[500];
            pa = 0;
            as = 0.5;
            rr = 0;
            j=0;
            ss = 0;
            kk = 0;
            nn = 0;
            p_dob = 0;
            o = 0;
            gg = 0;
            tt = 0;
            tamam = 0;
            ta = 0;
            nej = 0;
            mark1[500];
            soghot[500];
            jado[500];
            for (int i = 0; i < 500; ++i) {
                jado[i] = 0;
            }

            for (int i = 0; i < 500; ++i) {
                soghot[i] = 0;
            }

            for (int i = 0; i < 500; ++i) {
                mark1[i] = 0;
            }

            jav.erase(jav.begin(),jav.end());



            for (int i = 0; i < 500; ++i) {
                mark[i] = 0;
            }

            for (int jj = 0; jj < 3; ++jj) {
                for (int i = 0; i < 30; ++i) {
//             if(rand()%10!=0) {
                    k = rand() % 7;
                    if (k==6)
                    {
                        if (rand()%4==0)
                        {
                            k=6;
                        }
                        if (rand()%4==1)
                        {
                            k=1;
                        }
                        if (rand()%4==2)
                        {
                            k=2;
                        }
                        if (rand()%4==3)
                        {
                            k=3;
                        }
                    }
                    ran.push_back(k);
                    x.push_back(20 + 40 * i);
                    y.push_back(-100 + 35 * (2*jj));
                    ++sh;
                }
//        }
            }
/////////////////////////
            for (int jj = 0; jj < 3; ++jj) {
                for (int i = 0; i < 29; ++i) {
//             if(rand()%10!=0) {
                    k = rand() % 7;
                    if (k==6)
                    {
                        if (rand()%4==0)
                        {
                            k=6;
                        }
                        if (rand()%4==1)
                        {
                            k=1;
                        }
                        if (rand()%4==2)
                        {
                            k=2;
                        }
                        if (rand()%4==3)
                        {
                            k=3;
                        }
                    }
                    ran.push_back(k);
                    x.push_back(40 + 40 * i);
                    y.push_back(-100+ 35 * (2*jj+1));
                    ++sh;
                }
//        }
            }

        }
        if ((currentState == LOSE_PAGE || currentState == WIN_PAGE) && emtiaz > users[indexUser].data[2] ) users[indexUser].data[2] = emtiaz;
        // Update the screen
        SDL_RenderPresent(m_renderer);

    }

//    SDL_FreeSurface(textSurface);
//    SDL_DestroyTexture(textTexture);
//    TTF_CloseFont(font);
//    SDL_DestroyTexture(imageTexture);

}
